import React from 'react'
import 'animate.css'

function Chatleft(props) {
  
  return (
    <>
    {/* <div  style={{marginBottom:"20px"}}><span className="content clear">{props.content}</span></div> */}
    <div className="message1 left1 content animate__slideInUp">{props.content}</div>

    
    
    
    </>
  )
}

export default Chatleft