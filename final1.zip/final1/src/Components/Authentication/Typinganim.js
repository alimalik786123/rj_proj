import React from 'react'
import Typing from './typing.gif'
function Typinganim() {
  return (
    <div><div className=""><img className='message1 left1 typing' src={Typing} alt="" /></div></div>
  )
}

export default Typinganim